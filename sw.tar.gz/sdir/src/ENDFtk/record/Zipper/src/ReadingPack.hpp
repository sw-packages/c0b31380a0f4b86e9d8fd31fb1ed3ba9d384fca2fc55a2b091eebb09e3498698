template< typename Iterator >
struct ReadingPack{
  Iterator& it;
  const Iterator& end;
  long& lineNumber;
  int MAT, MF, MT;

  ReadingPack( Iterator& it, const Iterator& end, long& lineNumber,
               int MAT, int MF, int MT ) :
    it( it ), end( end ), lineNumber( lineNumber ),
    MAT( MAT ), MF( MF ), MT( MT ){}
};
