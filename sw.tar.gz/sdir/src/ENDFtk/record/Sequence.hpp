struct Sequence {
#include "ENDFtk/record/Sequence/src/read.hpp"
};
