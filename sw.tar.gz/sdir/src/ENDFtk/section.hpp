namespace section{

#include "ENDFtk/section/BaseWithoutMT.hpp"
#include "ENDFtk/section/Base.hpp"

template< int MF, int... OptionalMT >
class Type;

#include "ENDFtk/section/1.hpp"
#include "ENDFtk/section/2.hpp"
#include "ENDFtk/section/3.hpp"
#include "ENDFtk/section/6.hpp"
#include "ENDFtk/section/7.hpp"
#include "ENDFtk/section/8.hpp"
#include "ENDFtk/section/13.hpp"
}
