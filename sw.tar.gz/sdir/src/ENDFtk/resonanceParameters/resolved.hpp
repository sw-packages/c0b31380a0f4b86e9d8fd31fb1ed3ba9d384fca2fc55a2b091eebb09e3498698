namespace resolved {

#include "ENDFtk/resonanceParameters/resolved/BreitWigner.hpp"
#include "ENDFtk/resonanceParameters/resolved/SingleLevelBreitWigner.hpp"
#include "ENDFtk/resonanceParameters/resolved/MultilevelBreitWigner.hpp"
#include "ENDFtk/resonanceParameters/resolved/ReichMoore.hpp"
/*
#include "ENDFtk/resonanceParameters/resolved/RMatrixLimited.hpp"
*/

}
