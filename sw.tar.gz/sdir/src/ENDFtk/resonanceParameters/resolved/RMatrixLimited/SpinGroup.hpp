class SpinGroup  {
public:
  LIST channelDescriptions;
  LIST resonanceEnergyWidths;

  int KBK;
  int KPS;

  #include "ENDFtk/resonanceParameters/resolved/RMatrixLimited/SpinGroup/src/ctor.hpp"
};
