DefinedElsewhere ( int LAW ) : law_( LAW ) {

  checkLAW( this->LAW() );
}

