namespace record {

#include "ENDFtk/record/helper.hpp"
#include "ENDFtk/record/Tail.hpp"
#include "ENDFtk/record/TailVerifying.hpp"
#include "ENDFtk/record/Character.hpp"
#include "ENDFtk/record/Integer.hpp"
#include "ENDFtk/record/Real.hpp"
#include "ENDFtk/record/Base.hpp"
#include "ENDFtk/record/Zipper.hpp"
#include "ENDFtk/record/Sequence.hpp"
#include "ENDFtk/record/skip.hpp"
#include "ENDFtk/record/InterpolationBase.hpp"

}



